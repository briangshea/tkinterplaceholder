# TkInterPlaceHolder
A small set of themed tk widgets that implemnt placeholder text

